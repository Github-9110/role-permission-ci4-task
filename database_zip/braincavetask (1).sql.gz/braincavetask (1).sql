-- Adminer 4.8.1 MySQL 10.6.7-MariaDB-2ubuntu1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `section_id` varchar(50) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL COMMENT 'role name or type of role',
  `status` int(1) NOT NULL DEFAULT 1 COMMENT 'status 1 means active and 0 means inactive',
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'creation date show that which date record is created',
  `updation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'updation date show last date of updation',
  `created_by` int(11) NOT NULL COMMENT 'who create this record	',
  `updated_by` int(11) NOT NULL COMMENT 'who updated this record',
  `is_deleted` int(1) NOT NULL DEFAULT 0 COMMENT 'if record is deleted it would be 0 if not deleted it have default value 1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `email` varchar(200) NOT NULL,
  `role_id` int(11) NOT NULL,
  `password` varchar(200) NOT NULL,
  `is_deleted` int(2) NOT NULL DEFAULT 0 COMMENT '1 is deleted value and 0 not deleted',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `name`, `mobile`, `email`, `role_id`, `password`, `is_deleted`) VALUES
(1,	'admin',	'1234567891',	'admin@gmail.com',	1,	'123456',	0),
(2,	'name-test',	'9874563215',	'testuser123@gmail.com',	1,	'123456',	0),
(3,	'name-demo',	'1234567865',	'namedemo123@gmail.com',	2,	'123456',	0);

-- 2023-10-29 04:53:51
